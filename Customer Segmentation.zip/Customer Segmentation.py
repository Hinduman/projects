''' This program plots the centroids of customer segments with data, in graph,
    taken from 'Mall.csv' file. The dataset file, collected from online
    e-commerce website, has 4 different types of values like gender, age, income
    and spending percentage of random customers who have previously shopped
    Requirements:
    Python >= 3.8, numpy >= 1.17.4, matplotlib >= 3.1.2, scipy >= 1.3.3'''
import csv
# This program requires numpy, scipy and matplotlib modules installed from pip commands
import numpy as np
import matplotlib.pyplot as plt
from scipy.cluster.vq import kmeans
# Function which plots graph
def func(arg,arg1,k):
    fig=plt.figure()
    plt.plot(*arg,'o',label='Readings of each')
    plt.plot(*kmeans(arg.T,k)[0].T,'ro',label='Centroid of each cluster')
    plt.xlabel(arg1[0])
    plt.ylabel(arg1[1])
    fig.legend()
    fig.show()
# Read data from csv file
var=list(csv.DictReader(open('Mall.csv')))
# Graph which visualizes distribution of Age and Gender
var1=np.array([[int(x['Age']) for x in var if x['Gender'] == 'Male'],
               [int(x['Age']) for x in var if x['Gender'] == 'Female']])
fig=plt.figure(0)
plt.plot(var1[0],'x',label='Male Population')
plt.plot(var1[1],'o',label='Female Population')
plt.ylabel('Age of individuals')
fig.legend()
fig.show()
''' Following part plots Income vs Spending, Age vs Income and Age vs Spending
    along with centroids using kmeans function from scipy library
    kmeans function calculate centroids using K-means clustering algorithm of ML domain'''
var1=np.array([[float(x['Income']) for x in var],[float(x['Spend']) for x in var]])
func(var1,'Income in k$ and Spending %'.split(' and '),5)
var1=np.array([[float(x['Age']) for x in var],[float(x['Income']) for x in var]])
func(var1,'Age of people and Income in k$'.split(' and '),3)
var1=np.array([[float(x['Age']) for x in var],[float(x['Spend']) for x in var]])
func(var1,'Age of people and Spending %'.split(' and '),2)

